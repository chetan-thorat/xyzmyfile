package com.city.Entity;

import java.util.List;
import java.util.Objects;

public class Trees {
	private List<String> list;

	public Trees(List<String> list) {
		super();
		this.list = list;
	}

	public List<String> getList() {
		return list;
	}

	public void setList(List<String> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return "Trees [list=" + list + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(list);
	}

	@Override
	public boolean equals(Object obj) {
		
		Trees other = (Trees) obj;
		return Objects.equals(list, other.list);
	}
	
	

}
