package com.city.Entity;

import java.util.List;
import java.util.Objects;

public class City implements Comparable<City>{
	private String city;
	public City(String city) {
		super();
		this.city = city;
	}
	
	
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	@Override
	public String toString() {
		return "City [city=" + city + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(city);
	}
	@Override
	public boolean equals(Object obj) {
		
		City other = (City) obj;
		return Objects.equals(city, other.city);
	}


	@Override
	public int compareTo(City o) {
		// TODO Auto-generated method stub
		return this.city.compareTo(o.city);
	}
	
	
	
}
