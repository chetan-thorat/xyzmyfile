package com.city.Service;

import java.util.List;
import java.util.Map;

import com.city.Entity.City;
import com.city.Entity.Trees;

public interface CityService {

	List<Trees> findTreeList(String cname);

	boolean deleteTreeList(String cname);

	Map<City, Trees> displayData();

}
