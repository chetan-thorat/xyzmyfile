package com.city.Test;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.city.Entity.City;
import com.city.Entity.Trees;
import com.city.Service.CityService;
import com.city.Service.CityServiceImpl;

public class TestCity {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		CityService cs = new CityServiceImpl();
		
		int ch =0;
		
		do {
			System.out.println("1. Find list of trees for a city");
			System.out.println("2. Delete List of a particular city ");
			System.out.println("3. Add new entry in treemap (Check whether city name already exists) ");
			System.out.println("4. Display all city names and List of trees (Use Iterator and foreach)");
			System.out.println("5. Add a new tree in existing list ");
			System.out.println("6. Accept tree name from user. Display all cities in which the tree exists ");
			System.out.println("Enter your Choice ");
			ch= sc.nextInt();
			
			switch (ch) {
			
			case 1:
				System.out.println("Enter the city name for List of Trees :");
				String cname = sc.next();
				
				List<Trees> tlist = cs.findTreeList(cname);
				
				if(tlist != null)
				{
					tlist.forEach(System.out::println);
				}
				else
				{
					System.out.println("Not Found");
				}
				
				break;
				
			case 2:
				System.out.println("Enter the city name for List of Trees :");
				cname = sc.next();
				boolean status = cs.deleteTreeList(cname);
				if(status)
				{
					System.out.println("Deleted Succesfully");
				}
				else {
					System.out.println("Not found");
				}
				
				break;
				
			case 3:
				
				break;
				
			case 4:
				Map<City,Trees> cmap = cs.displayData();
				cmap.forEach((c1,c2)-> {
					System.out.println(c1+" -----> "+c2);
				});
				break;
				
			case 5:
				sc.close();
				System.out.println("Thank You.....");
				
				break;
				

			default:
				System.out.println("Wrong Choice");
				break;
			}
			
		} while (ch!=5);
	}

}
