import java.util.Date;

public class Employee extends SportClub{
	private String dept;
	private String desg;
	private Date date;
	
	
	public Employee() {
		this.dept = null;
		this.desg = null;
		this.date = null;
	}
	public Employee( String id,String name, String mob, String emailId, String dept, String desg, Date date) {
		super("E", name,  mob,  emailId);
		this.dept = dept;
		this.desg = desg;
		this.date = date;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDesg() {
		return desg;
	}
	public void setDesg(String desg) {
		this.desg = desg;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return super.toString()+"Employee [dept=" + dept + ", desg=" + desg + ", date=" + date + "]";
	}
	
	
	
}
