import java.util.Date;

public class ContractEmp extends Employee {
	private int numberOfHour;
	private int hourRate;
	
	public ContractEmp() {
		this.numberOfHour = 0;
		this.hourRate = 0;
	}

	public ContractEmp(String name, String mob, String emailId, String dept, String desg, Date date,int numberOfHour, int hourRate) {
		super("C",name,mob,emailId,dept,desg, date);
		this.numberOfHour = numberOfHour;
		this.hourRate = hourRate;
	}

	public int getNumberOfHour() {
		return numberOfHour;
	}

	public void setNumberOfHour(int numberOfHour) {
		this.numberOfHour = numberOfHour;
	}

	public int getHourRate() {
		return hourRate;
	}

	public void setHourRate(int hourRate) {
		this.hourRate = hourRate;
	}
	
	public double calSal() {
		
		return numberOfHour * hourRate;
	}

	@Override
	public String toString() {
		return super.toString()+ "ContractEmp [numberOfHour=" + numberOfHour + ", hourRate=" + hourRate + "]";
	}
	
	
}
