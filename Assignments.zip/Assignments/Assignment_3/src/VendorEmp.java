import java.util.Date;

public class VendorEmp extends Employee {
	private int noOfEmp;
	private int amount;
	
	
	public VendorEmp() {
	
		noOfEmp =0;
		amount = 0;
	}
	
	public VendorEmp(String name, String mob, String emailId, String dept, String desg, Date date,int noOfEmp, int amount) {
		super("V",name, mob, emailId,dept,desg,date);
		this.noOfEmp = noOfEmp;
		this.amount = amount;
	}

	public int getNoOfEmp() {
		return noOfEmp;
	}

	public void setNoOfEmp(int noOfEmp) {
		this.noOfEmp = noOfEmp;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	public double calSal() {
		return amount+(amount*0.18);
	}
	
	
	@Override
	public String toString() {
		return super.toString() +"VendorEmp [noOfEmp=" + noOfEmp + ", amount=" + amount + "]";
	}
	
	
	
	
}
