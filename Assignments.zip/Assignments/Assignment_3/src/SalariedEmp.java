import java.util.Date;

public class SalariedEmp extends Employee{
	private long basicSal;

	
	public SalariedEmp() {
		this.basicSal = 0;
	}
	public SalariedEmp(String name, String mob, String emailId, String dept, String desg, Date date, long basicSal) {
		super("S",name, mob,emailId, dept,desg, date);
		this.basicSal = basicSal;
	}
	
	
	public void setBasicSal(int sal) {
		basicSal = sal;
	}
	
	public long getBasicSal() {
		return basicSal;
	}
	
	
	public double calSal() {
		double totalSal;
		double DA = basicSal * 0.10;
		double HRA =basicSal * 0.15; 
		double pf = basicSal * 0.12;
		totalSal = basicSal + DA + HRA - pf ;
		return totalSal;
	}
	@Override
	public String toString() {
		return super.toString()+"SalariedEmp [basicSal=" + basicSal + "]";
	}
	
	
}
