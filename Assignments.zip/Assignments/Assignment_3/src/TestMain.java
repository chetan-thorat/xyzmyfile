import java.util.Date;
import java.util.Scanner;
public class TestMain {

	public static void main(String[] args) {
//		SalariedEmp ob = new SalariedEmp("S","RAM","256377778","ram@gmail.com","sales","HR",new Date(12142999),20000);
//		System.out.println(ob);
//		System.out.println(ob.calSal());
		
		
//		ContractEmp ob= new ContractEmp("C","RAM","256377778","ram@gmail.com","sales","HR",new Date(12142999),23,1000);
//		System.out.println(ob);
		
		
//		VendorEmp ob= new VendorEmp("C","RAM","256377778","ram@gmail.com","sales","HR",new Date(12142999),20,2000);
//		System.out.println(ob);
		
		Scanner sc = new Scanner(System.in);
		int choice;
		do{
			System.out.println("1. Display All employees by category\n2. Search by id\n3. Search by name\n4. Display all employee\n5. calculate salary and display for all emplyees with particular designation\n6. accept department from user and display 5 employees of that department.\n7. Exit\n");  
			System.out.print("Choose option: ");
			choice = sc.nextInt();
			
			switch(choice) {
			case 1:
				Service.displayAllEmp();
				break;
			case 2:
				Service.searchById();
				break;
			case 3:
				Service.searchByName();
				break;
			case 4:
				Service.displayAll();
				break;
			case 5:
				Service.displaySalary();
				break;
			case 6:
				Service.displayEmp();
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Ooops Wrong choice.......!");
			
			}
			
		}while(choice!=7);
		
		
	}

}
