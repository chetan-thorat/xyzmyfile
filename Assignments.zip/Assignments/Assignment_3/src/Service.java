import java.util.Date;
import java.util.Scanner;
public class Service {
	static Scanner sc = new Scanner(System.in);
	public static Employee[] earr;
	public static int count;
	static {
		
		earr = new Employee[100];
		earr[0] = new SalariedEmp("RAM","256377778","ram@gmail.com","sales","HR",new Date(12042019),20000);
		earr[1] = new ContractEmp("SITA","223452278","sita@gmail.com","Engineer","Backend Developer",new Date(19022002),23,1000);
		earr[2] = new VendorEmp("Chetan","9856377778","chetan@gmail.com","Test Enginner","Tester",new Date(18022002),20,2000);
		earr[3] = new SalariedEmp("Dyaneshwari","4572563777","dynanu@gmail.com","Engineer","Frontend Developer",new Date(14122024),30000);
		earr[4] = new ContractEmp("Mayur","77256377778","mayur@gmail.com","sales","HR",new Date(12112013),12,2000);
		earr[5] = new SalariedEmp("Radha","562227778","radha@gmail.com","sales","HR",new Date(12042019),20000);
		earr[6] = new ContractEmp("Krishna","223452278","Krishna@gmail.com","Engineer","Backend Developer",new Date(19022002),23,1000);
		earr[7] = new VendorEmp("Anvi","9856377778","Anvi@gmail.com","Test Enginner","Tester",new Date(18022002),20,2000);
		earr[8] = new SalariedEmp("Hrudvi","4572563777","rudvi@gmail.com","sales","HR",new Date(14122024),30000);
		earr[9] = new ContractEmp("Shravani","77256377778","Shravani@gmail.com","sales","HR",new Date(12112013),12,2000);
		earr[10] = new SalariedEmp("Vaishnavi","256377778","Vaishnavi@gmail.com","sales","HR",new Date(12042019),20000);
		earr[11] = new ContractEmp("Shruti","223452278","Shruti@gmail.com","Engineer","Backend Developer",new Date(19022002),23,1000);
		earr[12] = new VendorEmp("Divyani","9856377778","Divyani@gmail.com","Test Enginner","Tester",new Date(18022002),20,2000);
		earr[13] = new SalariedEmp("Sanya","4572563777","Sanu@gmail.com","sales","HR",new Date(14122024),30000);
		earr[14] = new ContractEmp("Amol","77256377778","amol@gmail.com","sales","HR",new Date(12112013),12,2000);
		count=15;
		
	}	
	//Display data by category...!
	
	public static void displayAllEmp() {
		System.out.println("Please choose the category:\n1. Salaried Employee\n2. Contract Employee\n3. Vendor Employee");
		int userChoice = sc.nextInt();
		
		if (userChoice == 1) {
			for(int i=0; i<count; i++) {
				if(earr[i] instanceof SalariedEmp) {
					System.out.println(earr[i]);
				}
				
			}
			System.out.println();
		}
		else if (userChoice == 2) {
			for(int i=0; i<count; i++) {
				if(earr[i] instanceof ContractEmp) {
					System.out.println(earr[i]);
				}
				
			}
			System.out.println();
		}
		else {
			for(int i=0; i<count; i++) {
				if(earr[i] instanceof VendorEmp) {
					System.out.println(earr[i]);
				}
				
			}
			System.out.println();
		}
	}
	
	
	//Display data by ID
	
	public static void searchById() {
		System.out.print("Enter id: ");
		String userChoice = sc.next();
		for(int i=0; i<count; i++) {
			if(userChoice.equalsIgnoreCase(earr[i].getIdtype())) {
				System.out.println(earr[i]);
			}
		}
		
	}
	
	
	
	//Search By Name function
	
	public static void searchByName() {
		System.out.print("Enter name: ");
		String userChoice = sc.next();
		for(int i=0; i<count; i++) {
			if(userChoice.equalsIgnoreCase(earr[i].getEname())) {
				System.out.println(earr[i]);
			}
		}
	}
	
	//Display All Emp Details
	
	public static void displayAll() {
		for(int i=0; i<count; i++) {
			System.out.println(earr[i]);
		}
	}
	
	// Display Salary of Employee
	
	public static void displaySalary() {
		for(int i=0;i<count;i++) {
			if(earr[i] instanceof SalariedEmp) {
				SalariedEmp se = (SalariedEmp) earr[i];
				System.out.print(earr[i].getEname()+"  |  "+ earr[i].getDesg()+"  |  "+ se.calSal()+"\n");
			}
			
			if(earr[i] instanceof ContractEmp) {
				ContractEmp ce = (ContractEmp) earr[i];
				System.out.print(earr[i].getEname()+"  |  "+ earr[i].getDesg()+"  |  "+ ce.calSal()+"\n");
			}
			
			if(earr[i] instanceof VendorEmp) {
				VendorEmp ve = (VendorEmp) earr[i];
				System.out.print(earr[i].getEname()+"  |  "+ earr[i].getDesg()+"  |  "+ ve.calSal()+"\n");
			}
		}
		System.out.println();
	}
	
	
	//  accept department from user and display 5 employees of that department. 
	
	public static void displayEmp() {
		int curr = 0;
		int i = 0;
		System.out.print("Enter department: ");
		String userDept= sc.next();
		do {
			
			if(userDept.equalsIgnoreCase(earr[curr].getDept())) {
				System.out.println(earr[curr].getIdtype()+"  |  " + earr[curr].getEname() + "  |  "+earr[curr].getDept());
				i++;
			}
			curr+=1;
			
		}while(i != 5);
		
	}
}
