
public class SportClub {
	private String idtype;
	private String ename;
	private String mob;
	private String emailId;
	static int count=0;	
	
	public SportClub() {
		this.idtype = null;
		this.mob = null;
		this.emailId = null;
	}
	public SportClub(String idtype, String name, String mob, String emailId) {
		this.idtype = autoGenerate(idtype);
		this.ename = name;
		this.mob = mob;
		this.emailId = emailId;
	}
	
	public String autoGenerate(String myId) {
		count = count + 1;
		myId = myId+count;
		return myId;
	}
	
	public String getIdtype() {
		return idtype;
	}
	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "SportClub [idtype=" + idtype + ", ename=" + ename + ", mob=" + mob + ", emailId=" + emailId + "]";
	}
	
	
	
	
}
