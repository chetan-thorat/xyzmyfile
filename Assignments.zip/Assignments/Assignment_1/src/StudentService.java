import java.util.*;

public class StudentService {
	static Scanner sc =  new Scanner(System.in);
	static Student[] parr=new Student[5];
	
	static {
		parr[0]= new Student("Chetan",60,70,80);
		parr[1]= new Student("Manish",70,70,90);
		parr[2]= new Student("Dhyaneshwari",76,86,86);
		parr[3]= new Student("Mayur",60,70,80);
		parr[4]= new Student("Divyani",100,100,100);
	}
	
	public static void displayAll(){
		for(int i=0; i<parr.length;i++) {
			System.out.println(parr[i]+"\n");
			
		}
	}
	
	public static void searchById() {
		System.out.print("Enter id: ");
		int u_input = sc.nextInt();
		for(int i=0; i<parr.length;i++) {
			if(parr[i].getId() == u_input) {
				System.out.println(parr[i]+"\n");
			}
			
		}
	}
	public static void searchByName() {
		System.out.print("Enter name: ");
		String u_input = sc.next();
		for(int i=0; i<parr.length;i++) {
			if(parr[i].getSname().equalsIgnoreCase (u_input)) {
				System.out.println(parr[i]+"\n");
			}
			
		}
	}
	public static void calculateGpa() {
		for(int i=0; i<parr.length;i++) {
			System.out.println(parr[i]+"\n");
			System.out.print("The GPA is: ");
			System.out.println((1.0/3)*parr[i].getM1()+(1.0/2)*parr[i].getM2()+(1.0/4)*parr[i].getM3()+" \n\n");
			
		}
	}
	
}
