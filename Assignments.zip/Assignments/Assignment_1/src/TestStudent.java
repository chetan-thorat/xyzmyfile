import java.util.*;
public class TestStudent {

	private static int userChoice;

	public static void main(String[] args) {

//		Student s= new Student("ram", 50,65,70);
//		System.out.println(s);
//		System.out.println();
//		
//		Student s1= new Student("sita", 100,199,100);
//		System.out.println(s1);
		
		Scanner sc = new Scanner(System.in);
		do{
		
		System.out.println("1. Display all Students\n2. Search by id\n3. Search by name\n4. calculate GPA of a student\n5. Exit\n");		
		System.out.print("Select your choice: ");
		int userChoice = sc.nextInt();
		
		switch (userChoice) {
		
		case 1: 
			StudentService.displayAll();
			break;
		case 2:
			StudentService.searchById();
			break;
		case 3:
			StudentService.searchByName();
			break;
		case 4:
			StudentService.calculateGpa();
			break;
		case 5:
			System.exit(0);
			break;
		default:
			System.out.println("Oppss...Wrong choice ! .... Please Enter the correct choice\n");
		}
		
		
		}while(userChoice!=5);
	}

}
