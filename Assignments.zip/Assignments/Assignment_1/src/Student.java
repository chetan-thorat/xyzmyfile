
public class Student {
	private int id;
	private String sname;
	private int m1;
	private int m2;
	private int m3;
	static int count=0;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getM1() {
		return m1;
	}

	public void setM1(int m1) {
		this.m1 = m1;
	}

	public int getM2() {
		return m2;
	}

	public void setM2(int m2) {
		this.m2 = m2;
	}

	public int getM3() {
		return m3;
	}

	public void setM3(int m3) {
		this.m3 = m3;
	}

	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		Student.count = count;
	}

	public Student(){
		id=++count;
		sname=null;
		m1=m2=m3=0;
	}
	
	public Student(String name, int m1, int m2, int m3) {
		id=++count;
		sname=name;
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
	}
	public String toString() {
		return "id: "+id+"\nname: "+sname+"\nm1: "+m1+"\nm2: "+m2+"\nm3: "+m3;
	}
}