package com.team.Dao;

import com.team.Entity.Player;
import com.team.Entity.Team;

public interface TeamDao {

	void save(Team t);

	boolean deleteTeam(int tid);

	boolean deletePlayer(int tid, int pid);

	void getTeam();

	void findBatsman(int tid);

	void showSprciality(int tid, String sp);

	boolean addPlayer(int tid, Player player);

	boolean updateCoach(int tid, String name);

}
