package com.team.Entity;

import java.util.List;


public class Team {
	private int teamid;
	private String tname, coachname;
	private List<Player> players;
	

	public Team(int teamid, String tname, String coachname, List<Player> players) {
		super();
		this.teamid = teamid;
		this.tname = tname;
		this.coachname = coachname;
		this.players = players;
	}


	public int getTeamid() {
		return teamid;
	}

	public String getTname() {
		return tname;
	}

	public String getCoachname() {
		return coachname;
	}

	public List<Player> getPlayers() {
		return players;
	}

	public void setTeamid(int teamid) {
		this.teamid = teamid;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public void setCoachname(String coachname) {
		this.coachname = coachname;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}

	@Override
	public String toString() {
		return "Team [teamid=" + teamid + ", tname=" + tname + ", coachname=" + coachname + ",\n players=\n" + players
				+ "]";
	}
	
	
	
	
}
