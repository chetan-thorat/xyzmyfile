import java.util.*;
public class FriendMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int choice;
		do{
		System.out.println("1. Display All Friend \r\n2. Search by id \r\n3. Search by name \r\n4. Display all friend with a particular hobby\r\n5. Exit");
		
		choice=sc.nextInt();
		
		switch(choice){
			case 1:
				FriendService.displayAll();
				break;
			case 2:
				System.out.print("Enter id to search: ");
				int id = sc.nextInt();
				FriendService.searchById(id);
				break;
			case 3:
				System.out.print("Enter name to search: ");
				String mystr = sc.next();
				FriendService.searchByName(mystr);
				break;
			case 4:
				System.out.print("Enter hobby name to search: ");
				mystr = sc.next();
				FriendService.displayByHooby(mystr);
				break;
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Entry");
		}
		}while(choice!=5);

}
}
