import java.util.Arrays;
import java.util.Date;

public class Friend {
	private int fid;
	private String name;
	private String lastname;
	private String[] hobbies;
	private String mobno;
	private String email;
	private Date bdate;
	private String address;
	static private int count=0;
	
	
	public Friend() {
		fid=++count;
		name=null;
		lastname=null;
		hobbies=null;
		mobno=null;
		email=null;
		bdate=null;
		address=null; 	
	}
	public Friend(String name, String lastname, String[] hobbies, String mobno, String email, Date bdate, String address) {
		fid=++count;
		this.name=name;
		this.lastname=lastname;
		this.hobbies=hobbies;
		this.mobno=mobno;
		this.email=email;
		this.bdate=bdate;
		this.address=address; 
		
	}
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String[] getHobbies() {
		return hobbies;
		
	}
	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getBdate() {
		return bdate;
	}
	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public static int getCount() {
		return count;
	}
	public static void setCount(int count) {
		Friend.count = count;
	}
	@Override
	public String toString() {
		return "Friend [fid=" + fid + ", name=" + name + ", lastname=" + lastname + ", hobbies="
				+ Arrays.toString(hobbies) + ", mobno=" + mobno + ", email=" + email + ", bdate=" + bdate + ", address="
				+ address;
	}
	
	
}
