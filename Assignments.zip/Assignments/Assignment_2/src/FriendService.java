import java.sql.Date;
import java.util.Arrays;
import java.util.Scanner;

public class FriendService {
	static Friend[] parr=new Friend[5];
	
	static {
		parr[0]= new Friend("Chetan", "Thorat", new String[]{"Cricket", "Movies"}, "8948203422", "chetan@gmail.com", new Date(12122013), "Ideal colony");
		parr[1]= new Friend("Dnyaneshwari", "Chaugule", new String[]{"Reading","Dancing"}, "834103422", "chaugule@gmail.com", new Date(12122013), "Mayur colony");
		parr[2]= new Friend("Shruti", "Rasane", new String[]{"Singing","Dancing"}, "558203422", "shruti@gmail.com", new Date(12122013), "Ideal colony");
		parr[3]= new Friend("Ram", "Gupta", new String[]{"Reading","Watching news"}, "9248203422", "ram@gmail.com", new Date(12122013), "God colony");
		parr[4]= new Friend("Sita", "Mehta", new String[]{"Reading","Dancing"}, "9878203422", "sita@gmail.com", new Date(12122013), "Shivaji colony");
		
	}

	
	public static void displayAll() {
		for(int i=0; i<parr.length; i++) {
			System.out.println(parr[i]);
		}
	}
	public static void searchById(int myid) {
		for(int i=0; i<parr.length; i++) {
			if(parr[i].getFid() == myid) {
				System.out.println(parr[i]);
			}
		}
	}
	
	
	public static void searchByName(String myname) {
		for(int i=0; i<parr.length; i++) {
			if(myname.equalsIgnoreCase(parr[i].getName())) {
				System.out.println(parr[i]);
			}
		}
	}
	
	
	public static void displayByHooby(String hobby) {
		for(int i=0; i<parr.length; i++) {
			String[] myhob = parr[i].getHobbies();
			
			
			
			for(int j=0;j<myhob.length;j++) {
				if(hobby.equalsIgnoreCase(myhob[j])) {
				//if (hobby.trim().equalsIgnoreCase(myhob[j].trim()))
					System.out.println(parr[i]);
					break;
				}
			}
				
			
		}
	}
}
