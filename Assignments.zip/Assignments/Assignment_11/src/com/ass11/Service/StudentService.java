package com.ass11.Service;

import java.util.List;
import java.util.Set;

import com.ass11.Entity.Student;

public interface StudentService {

	boolean addStudent();

	void displayAll();

	boolean addSSkills(int id, int cnt);

	boolean deleteStudent(int id);

	boolean deleteSkill(int id, String skill);

	List<Student> getStudentBySkill(String skill);

	List<Student> getStudentByDegree(String degree);

}
