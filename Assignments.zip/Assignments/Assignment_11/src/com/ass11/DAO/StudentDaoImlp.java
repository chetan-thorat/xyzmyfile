package com.ass11.DAO;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.ass11.Entity.Student;
import com.ass11.Entity.StudentSkills;

public class StudentDaoImlp implements StudentDao {
	
	static Map<Student,StudentSkills> smap = new HashMap<>();
	static {
		Set<String> skill = new HashSet<>();
		skill.add("java");
		skill.add("Python");
		skill.add("AI/ML");
		skill.add("DotNet");
		
		smap.put(new Student(101,"Durgesh","BE",LocalDate.of(2023, 11,10),76), new StudentSkills(skill));
		
		Set<String> skill1 = new HashSet<>();
		skill1.add("C++");
		skill1.add("java");
		skill1.add("Microsrives");
		skill1.add("SpringBoot");
		
		smap.put(new Student(102,"Mukesh","BE",LocalDate.of(2024, 12,18),87), new StudentSkills(skill1));
	}
	@Override
	public boolean save(Student student, StudentSkills studentSkills) {
		if(smap.containsKey(new Student(student.getSid()))) {
			return false;
		}
		smap.put(student, studentSkills);
		return true;
		
	}
	@Override
	public void findAll() {
		 for(Map.Entry<Student, StudentSkills> m : smap.entrySet()) {
			 System.out.println(m.getKey()+" "+m.getValue());
		 }
		
	}
	@Override
	public boolean addSkill(int id, Set<String> s) {
		if(smap.containsKey(new Student(id))) {
			StudentSkills s1 = smap.get(new Student(id));
			s1.getSkills().addAll(s);
			return true;
		}
		return false;
	}
	@Override
	public boolean removeStudent(int id) {
		if(smap.containsKey(new Student(id))) {
			smap.remove(new Student(id));
			return true;
		}
		return false;
	}
	@Override
	public boolean reomveSkill(int id, String skill) {
		if(smap.containsKey(new Student(id))) {
			StudentSkills s1 = smap.get(new Student(id));
			s1.getSkills().remove(skill);
			return true;
		}
		return false;
	}
	@Override
	public List<Student> displayStudentBySkill(String skill) {
		List<Student> slist = new ArrayList<>();
		for(Map.Entry<Student, StudentSkills> s : smap.entrySet()) {
			for(String skills : s.getValue().getSkills()) {
				if(skills.equalsIgnoreCase(skill)) {
					slist.add(s.getKey());
				}
			}
		}
	
		return slist;
	}
	@Override
	public List<Student> displayStudentByDegree(String degree) {
//		List<Student> slist = new ArrayList<>();
		Set<Student> sset = smap.keySet();
//		for(Student s : sset) {
//			if(s.getDegree().equalsIgnoreCase(degree)) {
//				slist.add(s);
//			}
//		}
		
		return sset.stream()
				.filter(s->s.getDegree().equalsIgnoreCase(degree))
				.collect(Collectors.toList());
	}

}
