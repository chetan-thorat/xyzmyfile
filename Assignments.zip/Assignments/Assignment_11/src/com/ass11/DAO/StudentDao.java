package com.ass11.DAO;

import java.util.List;
import java.util.Set;

import com.ass11.Entity.Student;
import com.ass11.Entity.StudentSkills;

public interface StudentDao {

	boolean save(Student student, StudentSkills studentSkills);

	void findAll();

	boolean addSkill(int id, Set<String> s);

	boolean removeStudent(int id);

	boolean reomveSkill(int id, String skill);

	List<Student> displayStudentBySkill(String skill);

	List<Student> displayStudentByDegree(String degree);

}
