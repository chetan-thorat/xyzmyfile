package com.ass11.Entity;

import java.util.List;
import java.util.Set;

public class StudentSkills {
	
	private Set<String> skills;

	public StudentSkills(Set<String> skills) {
		super();
		this.skills = skills;
	}

	public Set<String> getSkills() {
		return skills;
	}

	public void setSkills(Set<String> skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "StudentSkills [skills=" + skills + "]";
	}

	

	

}
