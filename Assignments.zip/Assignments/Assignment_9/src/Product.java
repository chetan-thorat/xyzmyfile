import java.util.Date;

abstract public class Product {
	private int Id;
	private String name, type;
	private Date Mfgdate;
	
	public Product(int id, String name, String type, Date mfgdate) {
		super();
		Id = id;
		this.name = name;
		this.type = type;
		Mfgdate = mfgdate;
	}
	
	public int getId() {
		return Id;
	}
	public String getName() {
		return name;
	}
	public String getType() {
		return type;
	}
	public Date getMfgdate() {
		return Mfgdate;
	}
	
	public void setId(int id) {
		Id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setMfgdate(Date mfgdate) {
		Mfgdate = mfgdate;
	}
	
	abstract public double calculateTax();  
	
	@Override
	public String toString() {
		return "Product [Id=" + Id + ", name=" + name + ", type=" + type + ", Mfgdate=" + Mfgdate+ "]";
	}
	
	
}
