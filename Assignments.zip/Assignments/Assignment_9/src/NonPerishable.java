import java.util.Date;

public class NonPerishable extends Product {
	private String category;
	private double price;
	public NonPerishable(int id, String name, Date mfgdate, double price,String category) {
		super(id,name,"NonPerishable",mfgdate);
		this.category = category;
		this.price=price;
	}

	public String getCategory() {
		return category;
	}
	
	public double getPrice() {
		return price;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public double calculateTax()
	{
		return (this.price*0.15)+100;
	}

	@Override
	public String toString() {
		return super.toString()+"NonPerishable [category=" + category + ", price=" + price + "]";
	}

	
}
