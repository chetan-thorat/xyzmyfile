package demo.Emp.DAO;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import demo.Emp.Entity.Emp;

public class EmpDaoImpl implements EmpDao {
	static Set<Emp> eset = new HashSet<>();
	static {
		eset.add(new Emp(66,"Rahul","hr","mgr",30000));
		eset.add(new Emp(287,"Akash","sales","Account",15000));
		eset.add(new Emp(3,"Binod","Admin","mgr",25000));
		eset.add(new Emp(400,"Shraddha","hr","mgr",40000));
		eset.add(new Emp(55,"Sunny","Support","Associate",10000));
	}
	@Override
	public boolean save(Emp emp) {
		return eset.add(emp);
	}
	@Override
	public Set<Emp> findAll() {
		
		return eset;
	}
	@Override
	public Emp displayById(int id) {
		Optional<Emp> e1 = eset.stream().filter(e->e.getId() == id).findFirst();
		if(e1.isPresent()) {
			return e1.get();
		}
		return null;
	}
	@Override
	public List<Emp> displayByName(String name) {
		List<Emp> elist = new ArrayList<>();
		elist = eset.stream().filter(e-> e.getName().equalsIgnoreCase(name)).collect(Collectors.toList());
		return elist;
	}
	@Override
	public boolean removeEmp(int id) {
		return eset.remove(new Emp(id));
	}
	@Override
	public boolean modifySal(int id, double sal) {
		Optional<Emp> e1 = eset.stream().filter(e->e.getId() == id).findFirst();
		if(e1.isPresent()) {
			e1.get().setSal(sal);
			return true;
		}
		return false;
	
	}
	@Override
	public List<Emp> sortName() {
		Comparator<Emp> c = (o,o1) -> o.getName().compareTo(o1.getName());
		List<Emp> elist = new ArrayList<>();
		for(Emp e : eset) {
			elist.add(e);
		}
		elist.sort(c);
		return elist;
	}
	@Override
	public Set<Emp> sortById() {
		Set<Emp> tset = new TreeSet<>();
		for(Emp e : eset) {
			tset.add(e);
		}
		return tset;
	}
	@Override
	public List<Emp> arrangeBySal() {
		Comparator<Emp> c = (o,o1) ->(int) (o.getSal()-o1.getSal());
		List<Emp> elist = new ArrayList<>();
		for(Emp e : eset) {
			elist.add(e);
		}
		elist.sort(c);
		return elist;
	}
	@Override
	public Map<Integer, Emp> storeMap() {
		Map<Integer,Emp> emap = new TreeMap<>();
		for(Emp e : eset) {
			emap.put(e.getId(), new Emp(e.getName(),e.getDept(),e.getDesignation(),e.getSal()));
		}
		return emap;
	}
	
	

}
