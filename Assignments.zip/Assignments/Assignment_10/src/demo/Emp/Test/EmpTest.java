package demo.Emp.Test;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import demo.Emp.Entity.Emp;
import demo.Emp.Service.EmpService;
import demo.Emp.Service.EmpServiceImpl;

public class EmpTest {

	public static void main(String[] args) {
		EmpService eservice = new EmpServiceImpl();
		Scanner sc = new Scanner(System.in);
		
		int ch;
		
		do {
			System.out.println();
			System.out.println("1. Adding the new Employees");
			System.out.println("2. Display the Employees");
			System.out.println("3. Find Employee By ID");
			System.out.println("4. Find Employee By Name");
			System.out.println("5. Delete Employees");
			System.out.println("6. Modify Employee (Salary)");
			System.out.println("7. display in sorted order by name");
			System.out.println("8. Display in sorted order by id");
			System.out.println("9. Display in sorted order by sal");
			System.out.println("10. Store In TreeMap");
			System.out.println("11. Exit");
			System.out.println("Enter Your Choice :");
			ch = sc.nextInt();
			
			switch (ch) {
			
			case 1:
				boolean status = eservice.addEmp();
				if(status)
				{
					System.out.println("Employee Added.");
				}else {
					System.err.println("Duplicate Entry");
				}
				break;
				
			case 2:
				Set<Emp> eset = eservice.displayAll();
				eset.forEach(System.out::println);
				
				break;
				
			case 3:
				System.out.println("Enter The Employee Id :");
				int id = sc.nextInt();
				Emp e = eservice.findById(id);
				if(e != null)
				{
					System.out.println(e);
				}else {
					System.err.println("Employee not found");
				}
				break;
				
			case 4:
				System.out.println("Enter The Employee Name :");
				String name = sc.next();
				List<Emp> e1 = eservice.findByName(name);
				if(!e1.isEmpty())
				{
					e1.forEach(System.out::println);
				}else {
					System.err.println("Employee not found");
				}
				break;
				
			case 5:
				System.out.println("Enter The Employee Id :");
				id = sc.nextInt();
				status = eservice.deleteEmp(id);
				if(status)
				{
					System.out.println("Employee Deleted");
				}else {
					System.err.println("Employee not found");
				}
				break;
				
			case 6:
				System.out.println("Enter The Employee Id :");
				id = sc.nextInt();
				System.out.println("Enter New salary :");
				double sal = sc.nextDouble();
				status= eservice.updateBySal(id,sal);
				if(status)
				{
					System.out.println("Modified Succesfully");
				}else {
					System.err.println("Employee not found");
				}
				break;
				
			case 7:
				 e1 = eservice.sortByName();
				 e1.forEach(System.out::println);
				
				break;
				
			case 8:
				 Set<Emp> set = eservice.sortById();
				 set.forEach(System.out::println);
				break;
				
			case 9:
				 e1 = eservice.sortBySal();
				 e1.forEach(System.out::println);
				break;
			case 10:
				 Map<Integer,Emp> map = eservice.storeInTreeMap();
				 for(Map.Entry<Integer, Emp> emap : map.entrySet()) {
					 System.out.println("Id :"+ emap.getKey()+" --> Details :"+emap.getValue().display());
				 }
				break;	
			case 11:
				sc.close();
				System.out.println("Thank You........");
				break;
				
			default:
				System.out.println("You Entered Wrong Choice");
				break;
			}
		}while(ch!=11);

	}

}
