import java.util.Arrays;
import java.util.Date;

public class Exam {
	private int id;
	private String name;
	private String topic;
	private Date dateOfExam;
	
	public Exam() {
		super();
	}
	public Exam(int id, String name, String topic, Date dateOfExam) {
		super();
		this.id = id;
		this.name = name;
		this.topic = topic;
		this.dateOfExam = dateOfExam;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public Date getDateOfExam() {
		return dateOfExam;
	}
	public void setDateOfExam(Date dateOfExam) {
		this.dateOfExam = dateOfExam;
	}
	
	@Override
	public String toString() {
		return "Exam [id=" + id + ", name=" + name + ", topic=" + topic + ", dateOfExam=" + dateOfExam + "]";
	}
	
	
}
