import java.util.Date;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Java j= new Java(1,"Ram","OOPS", new Date("13/10/2024"), new  String[] {
			    "Which of the following is not a Java keyword? A) class B) interface C) extends D) main",
			    "What is the size of an int data type in Java? A) 64 bits B) 16 bits C) 32 bits D) 8 bits",
			    "Which of the following is the correct way to declare an array in Java? A) arr = int[5]; B) int arr = new int[5]; C) int arr[5]; D) int arr[] = new int[5];",
			    "Which of these access modifiers allows access to members of a class from any other class? A) private B) protected C) default D) public",
			    "What is the output of the following code snippet? System.out.println(10 + 20 + \"Java\"); A) Java1020  B) Java30 C) 1020Java D) 30Java"
			});
		System.out.println(j);
		
		HTML h= new HTML(2,"Sita","HTML", new Date("14/10/2024"),new String[] {
				"What does HTML stand for? A) Home Tool Markup Language  B) High Text Machine Language C) Hyperlink and Text Markup Language D) Hyper Text Markup Language ",
				 "Which HTML tag is used to define the largest heading? A) <head> B) <heading> C) <h6> D) <h1> ",
				 "Which attribute is used to provide a unique identifier to an HTML element? A) class B) style C) name D) id ",
				 "What is the correct HTML element for inserting a line break? A) <break> B) <lb> C) <line> D) <br> ",
				 "Which HTML tag is used to create a hyperlink? A) <link> B) <hyperlink> C) <href> D) <a>"
			});
		System.out.println(h);
		int a;
		int count = 0;
		Scanner sc = new Scanner(System.in);
		do {
		count=0;
		System.out.println("1. JAVA\n2. HTML");
		System.out.println("Enter the choice: ");
		int choice = sc.nextInt();
		
		if (choice == 1) {
			for(int i=0;i<j.getQuestions().length;i++) {
				System.out.println(j.getQuestions()[i]);
				System.out.println("Select answer :");
				int user_enter = sc.nextInt();
				if(user_enter == 4) {
					count=count+1;
				}
				
			}
		}
		else {
			for(int i=0;i<h.getQuestions().length;i++) {
				System.out.println(h.getQuestions()[i]);
				System.out.println("Select answer :");
				int user_enter = sc.nextInt();
				if(user_enter == 4) {
					count=count+1;}}
		}
		System.out.println("total marks :"+count);
		
		if (count >= 3) {
         System.out.println("congratulations you completed the test.");
		} else {
	         System.out.println("better luck next time.");
	     }

		System.out.println("do you want to continue press 1 for YES press 2 for No");
		a = sc.nextInt();

		}while(a==1);
		
		
}
}
