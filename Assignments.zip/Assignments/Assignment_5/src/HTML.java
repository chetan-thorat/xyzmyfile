import java.util.Arrays;
import java.util.Date;

public class HTML extends Exam{
	private String[] questions;

	public HTML() {
		super();
	}

	public HTML(int id, String name, String topic, Date dateOfExam,String[] questions) {
		super(id,name,topic,dateOfExam);
		this.questions = questions;
	}

	public String[] getQuestions() {
		return questions;
	}

	public void setQuestions(String[] questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return super.toString()+"HTML [questions=" + Arrays.toString(questions) + "]";
	}
	
	
}
