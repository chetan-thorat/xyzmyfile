import java.util.Arrays;
import java.util.Date;

public class Java extends Exam{
	
	private String[] questions;

	public Java() {
		super();
	}

	public Java(int id, String name, String topic, Date dateOfExam,String[] questions) {
		super(id,name,topic,dateOfExam);
		this.questions = questions;
	}

	public String[] getQuestions() {
		return questions;
	}

	public void setQuestions(String[] questions) {
		this.questions = questions;
	}
	
	@Override
	public String toString() {
		return super.toString()+ "Java [questions=" + Arrays.toString(questions) + "]";
	}

	
}
