import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ExamSerivce e = new ExamSerivce();
		int ch;
		do {
			System.out.println("1. Java\n2. HTML\n3. Exit\n Enter Choice :");
			ch = sc.nextInt();
			
		switch (ch) 
		
		{
		case 1:
			e.conductExam(ch);
			
			break;
			
		case 2:
			e.conductExam(ch);
			
			break;
		case 3:
			sc.close();
			System.out.println("Exit");
			
			break;

		default:
			System.out.println("Please select correct exam");
			break;
		}
		
		}
		while(ch!=3);
	}

}
