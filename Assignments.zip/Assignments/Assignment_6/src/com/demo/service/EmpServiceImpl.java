package com.demo.service;

import java.util.Scanner;
import java.util.Set;

import com.demo.beans.Employee;
import com.demo.dao.EmpDao;
import com.demo.dao.EmpDaoImpl;

public class EmpServiceImpl implements EmpService {
	private EmpDao edao;
	public EmpServiceImpl() {
		
		edao=new EmpDaoImpl();
	}
	@Override
	public boolean addEmp() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter emp id");
		int id=sc.nextInt();
		System.out.println("enter emp name");
		String name=sc.next();
		System.out.println("enter emp sal");
		double sal=sc.nextDouble();
		System.out.println("enter emp dept");
		String dept=sc.next();
		System.out.println("enter emp desg");
		String desg=sc.next();
		Employee emp= new Employee(id,name,sal,dept,desg);		
		return edao.save(emp);
	}
	@Override
	public void displayAll() {
		edao.showAll();
		
	}
	@Override
	public boolean deleteEmp(int id) {
		// TODO Auto-generated method stub
		return edao.removeEmp(id);
	}
	@Override
	public boolean modifyEmpSal(int id,double sal) {
		// TODO Auto-generated method stub
		return edao.modifySal(id,sal);
	}
	@Override
	public boolean displayEmpByDesg(String desg) {
		// TODO Auto-generated method stub
		return edao.showEmpDesg(desg);
	}
	@Override
	public Set<Employee> displayById() {
		
		return edao.sortByID()
	};
}
