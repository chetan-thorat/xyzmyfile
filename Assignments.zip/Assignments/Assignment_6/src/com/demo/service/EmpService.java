package com.demo.service;

import com.demo.beans.Employee;
import com.demo.test.Set;

public interface EmpService {

	boolean addEmp();

	void displayAll();

	boolean deleteEmp(int id);

	boolean modifyEmpSal(int id, double sal);

	boolean displayEmpByDesg(String desg);

	Set<Employee> displayById();

}
