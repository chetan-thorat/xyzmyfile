package com.demo.dao;

import com.demo.beans.Employee;

public interface EmpDao {

	boolean save(Employee emp);

	void showAll();

	boolean removeEmp(int id);

	boolean modifySal(int id , double sal);

	boolean showEmpDesg(String desg);
	
}
