package com.demo.dao;

import java.util.HashSet;
import java.util.Set;

import com.demo.beans.Employee;

public class EmpDaoImpl implements EmpDao {

		static Set<Employee> eset;
			static {
				eset=new HashSet<>();
				eset.add(new Employee( 1,"Ram",15000,"sales","hr"));
				eset.add(new Employee( 2,"Sita",12000,"Engineer","backendDeveloper"));
			}
			@Override
			public boolean save(Employee emp) {
				// TODO Auto-generated method stub
				return eset.add(emp);
			}
			@Override
			public void showAll() {
				for(Employee e:eset) {
					System.out.println(e);
				}
				
				
			}
			@Override
			public boolean removeEmp(int id) {
				for(Employee e:eset)
					if(e.getId()==id) {
						eset.remove(e);
						return true;}
				return false;
			}
			@Override
			public boolean modifySal(int id, double sal) {
				for(Employee e:eset)
					if(e.getId()==id) {
						e.setSal(sal);
						return true;}
				return false;
			}
			@Override
			public boolean showEmpDesg(String desg) {
				for(Employee e:eset)
					if(e.getDesg().equals(desg)) {
						System.out.println(e);
						return true;}
				return false;
			}
		
}
