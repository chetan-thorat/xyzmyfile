package com.demo.test;

import java.util.Scanner;
import java.util.Set;

import com.demo.beans.Employee;
import com.demo.service.EmpService;
import com.demo.service.EmpServiceImpl;

public class EmpTest {
		
	public static void main(String[] args) {
		EmpService es=new EmpServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice=0;
		do {
		System.out.println("1.add employee\n 2. delete employee\n3. modify Salary\n4 display Employee based on desg\n5 display all\n 6 Sort by ID\n 7 Sort by Sal\n8 exit\nEnter your Choice");
		choice=sc.nextInt();	
		switch(choice) {
		case 1:
			boolean status=es.addEmp();
			if(status)
				System.out.println("data added");
			else
				System.out.println("data not saved");
			break;
		case 2:System.out.println("enter id");
		int id=sc.nextInt();
		status=es.deleteEmp(id);
		if(status)
			System.out.println("deleted successfully");
		else
			System.out.println("not found");
			break;
		case 3:System.out.println("enter id");
		id=sc.nextInt();
		System.out.println("enter sal");
		double sal=sc.nextDouble();
		status=es.modifyEmpSal(id,sal);
		if(status)
			System.out.println("modify successfully");
		else
			System.out.println("not found");
			break;
		case 4:
			System.out.println("enter desg");
			String desg=sc.next();
			status=es.displayEmpByDesg(desg);
			if(status)
				System.out.println("display successfully");
			else
				System.out.println("not found");
				break;
		case 5:
			es.displayAll();
			break;
		case 6:
			Set<Employee> eset=es.displayById();
			eset.forEach(System.out::println);
			break;
		case 7:
			break;
		case 8:
			sc.close();
			System.out.println("thankyou!!!!!!!!!!!");
			break;
		default:
			System.out.println("wrong input");;
		}
		}while(choice!=8);
		
	}
}
