package com.demo.beans;

public class Employee{


	private int id;
	private String name;
	private double sal;
	private String detp;
	private String desg;
	public Employee() {
		super();
	}
	public Employee(int id, String name, double sal, String detp, String desg) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.detp = detp;
		this.desg = desg;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public String getDetp() {
		return detp;
	}
	public void setDetp(String detp) {
		this.detp = detp;
	}
	public String getDesg() {
		return desg;
	}
	public void setDesg(String desg) {
		this.desg = desg;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", sal=" + sal + ", detp=" + detp + ", desg=" + desg + "]";
	}
	
//	
	public boolean equals(Object obj) {
			return this.getId()==((Employee)obj).getId();
	}
	
	public int HashCode() {
		return id;
	}
	public Employee(int id) {
		super();
		this.id = id;
	}
//	public int compareTo(Person o) {
////		if(this.pid<o.pid)
////			return -1;
////		else if(this.pid==o.pid)
////			return 0;
////		else
////			return 1;
//		System.out.println("In comparable "+this.pid+"---"+o.pid);
//		return (this.id-o.id);
		
}


