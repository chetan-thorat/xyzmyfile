
public class Customer extends ABCTel{
	
	private String CreditClass;
	private String CustPlan;
	public Customer() {
		super();
	}
	public Customer(int id, String name, String email, String creditClass, String custPlan) {
		super(id, name, email);
		
		CreditClass = creditClass;
		CustPlan = custPlan;
	}
	
	
	public String getCreditClass() {
		return CreditClass;
	}
	public void setCreditClass(String creditClass) {
		CreditClass = creditClass;
	}
	public String getCustPlan() {
		return CustPlan;
	}
	public void setCustPlan(String custPlan) {
		CustPlan = custPlan;
	}
	@Override
	public String toString() {
		return super.toString()+"Customer [CreditClass=" + CreditClass + ", CustPlan=" + CustPlan + "]";
	}
	
	
}
