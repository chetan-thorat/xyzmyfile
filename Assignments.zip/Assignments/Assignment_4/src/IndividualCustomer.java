
public class IndividualCustomer extends Customer {
	private String PhoneNumber;

	public IndividualCustomer() {
		super();
	}

	public IndividualCustomer(int id, String name, String email, String creditClass, String custPlan, String phoneNumber) {
		super(id,name,email,creditClass,custPlan);
		PhoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return super.toString()+"IndividualCustomer [PhoneNumber=" + PhoneNumber + "]";
	}
	
	
}
