
public class Test {

	public static void main(String[] args) {
		IndividualCustomer ic = new IndividualCustomer(1,"Krishna","k@gmail.com","VIP","2 Years","223223442");
		System.out.println(ic);
		
		CompanyCustomer cc = new CompanyCustomer(2,"Radha","R@gmail.com","General Public","3 Years","Krishna","Personal Line of Credit","None",new String[]{"9876543210", "9123456789"});
		System.out.println(cc);
		
		Vendor v = new Vendor(3,"Mayur","M@gmail.com","2224634522", new String[] {"product1","product2","product3"});
		System.out.println(v);
	}

}
