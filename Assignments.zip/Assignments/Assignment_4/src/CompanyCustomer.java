import java.util.Arrays;

public class CompanyCustomer extends Customer{
	private String relationship_manager;
	private String credit_line;
	private String extension;
	private String[] number;
	public CompanyCustomer() {
		super();
	}
	public CompanyCustomer(int id, String name, String email, String creditClass, String custPlan,String relationship_manager, String credit_line, String extension, String[] number) {
		super(id,name,email,creditClass,custPlan);
		this.relationship_manager = relationship_manager;
		this.credit_line = credit_line;
		this.extension = extension;
		this.number = number;
	}
	public String getRelationship_manager() {
		return relationship_manager;
	}
	public void setRelationship_manager(String relationship_manager) {
		this.relationship_manager = relationship_manager;
	}
	public String getCredit_line() {
		return credit_line;
	}
	public void setCredit_line(String credit_line) {
		this.credit_line = credit_line;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String[] getNumber() {
		return number;
	}
	public void setNumber(String[] number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return super.toString()+"CompanyCustomer [relationship_manager=" + relationship_manager + ", credit_line=" + credit_line
				+ ", extension=" + extension + ", number=" + Arrays.toString(number) + "]";
	}
	
	
}
