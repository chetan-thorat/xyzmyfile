import java.util.Arrays;

public class Vendor extends ABCTel{
	private String phoneNumber;
	String[] ProductList;
	public Vendor() {
		super();
	}
	public Vendor(int id, String name, String email, String phoneNumber, String[] productList) {
		super(id,name ,email);
		this.phoneNumber = phoneNumber;
		ProductList = productList;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String[] getProductList() {
		return ProductList;
	}
	public void setProductList(String[] productList) {
		ProductList = productList;
	}
	@Override
	public String toString() {
		return super.toString()+"Vendor [phoneNumber=" + phoneNumber + ", ProductList=" + Arrays.toString(ProductList) + "]";
	}
	
}
