module Project1 {
	exports com.demo.packa;
	exports com.demo.packb;
}